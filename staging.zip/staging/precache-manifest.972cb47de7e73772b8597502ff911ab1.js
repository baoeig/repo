self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "2b356a45a6241e168e2b",
    "url": "/css/app.32114fed.css"
  },
  {
    "revision": "342e1a62107289937911",
    "url": "/css/chunk-7e278922.1642bd13.css"
  },
  {
    "revision": "ae0f4359bd90823389d6e57b303b3174",
    "url": "/img/apple-brands.ae0f4359.svg"
  },
  {
    "revision": "f3f55ba47b8e6f90bd1031c68dca77e5",
    "url": "/img/bCoin@2x.png"
  },
  {
    "revision": "e7c5d21fc53c863a5dae21a321f29562",
    "url": "/img/b_coin_popup.e7c5d21f.svg"
  },
  {
    "revision": "afe501ca799f64d9210db1e48349550d",
    "url": "/img/backBlack.afe501ca.svg"
  },
  {
    "revision": "395b4a31d45247751d58d8593e9f9d98",
    "url": "/img/backWhite.395b4a31.svg"
  },
  {
    "revision": "b9607337623c11bd92fdc2fc9ee80917",
    "url": "/img/bw-icon.b9607337.svg"
  },
  {
    "revision": "42f76ddf21319a931ce3b2c5287cd40a",
    "url": "/img/checkmark-black.42f76ddf.svg"
  },
  {
    "revision": "86c654f077f98b9543b78954452b9412",
    "url": "/img/clock.86c654f0.svg"
  },
  {
    "revision": "5513e2047dda3bd98e6b51a0524b3e2a",
    "url": "/img/close.5513e204.svg"
  },
  {
    "revision": "221b42fc3a4cd4f4d6805266c5f13df2",
    "url": "/img/combinedShape@2x.png"
  },
  {
    "revision": "ec61ce00261bb46f26b5fcb6350d1096",
    "url": "/img/correct@3x.png"
  },
  {
    "revision": "9357555aaaa42abd7cece04fa01281d5",
    "url": "/img/exchange-center-banner.9357555a.png"
  },
  {
    "revision": "9357555aaaa42abd7cece04fa01281d5",
    "url": "/img/exchange-center-banner.png"
  },
  {
    "revision": "ef3e3e7b86f8a7cc0870b3b7d88b9da1",
    "url": "/img/exchange-center.ef3e3e7b.svg"
  },
  {
    "revision": "777606d110ea55f8524876fccdc41aed",
    "url": "/img/eye.png"
  },
  {
    "revision": "5d24a4334a694c87f304e6407115664b",
    "url": "/img/facebook-brands-white.5d24a433.svg"
  },
  {
    "revision": "11834243862205db2d7c0cda6e98fa9f",
    "url": "/img/facebook-brands.11834243.svg"
  },
  {
    "revision": "69186010ebf326b8813eb3e928c20981",
    "url": "/img/faq.69186010.svg"
  },
  {
    "revision": "c477a29c9c995345262de1b3cefe3405",
    "url": "/img/femaleColor.png"
  },
  {
    "revision": "b6e14b53c17ee3d0cf1bedef690171d0",
    "url": "/img/femaleWhite.png"
  },
  {
    "revision": "734f8fa8be51cc15988dd3031e4fdd27",
    "url": "/img/google-brands.734f8fa8.svg"
  },
  {
    "revision": "cba982650baccc75c3809f512fd0e001",
    "url": "/img/hint.cba98265.svg"
  },
  {
    "revision": "b5aa263343ddbdb4672198a397af131d",
    "url": "/img/how-to-earn-points.b5aa2633.svg"
  },
  {
    "revision": "d35eefbf15b5bf40113f199a19640b63",
    "url": "/img/icRegularSubscribe.d35eefbf.png"
  },
  {
    "revision": "a1c8fbb33d2188d818772b8272c37506",
    "url": "/img/icicon2@2x.a1c8fbb3.png"
  },
  {
    "revision": "a1c8fbb33d2188d818772b8272c37506",
    "url": "/img/icicon2@2x.png"
  },
  {
    "revision": "55fcd06797e02335c2eb571b87537827",
    "url": "/img/iconPerson@2x.55fcd067.png"
  },
  {
    "revision": "55fcd06797e02335c2eb571b87537827",
    "url": "/img/iconPerson@2x.png"
  },
  {
    "revision": "6d9ac81d78e56d1d2ba1e49a1276d87e",
    "url": "/img/info-dark.6d9ac81d.svg"
  },
  {
    "revision": "abb01a853b1b88a049b5922e8798a39a",
    "url": "/img/infoNormal@2x.png"
  },
  {
    "revision": "a6052ee59ded8389d776469dea2fdf51",
    "url": "/img/line-brands-white.a6052ee5.svg"
  },
  {
    "revision": "eda77f2accfaf3885d7ab3a9d6fa8b07",
    "url": "/img/line-brands.eda77f2a.svg"
  },
  {
    "revision": "274decc6f16b4472d31eb43736b61c30",
    "url": "/img/maleColor.png"
  },
  {
    "revision": "3cc18edc5611a8ff8d5ff7c288188ac6",
    "url": "/img/my-points.3cc18edc.svg"
  },
  {
    "revision": "80eadca6026238350d0e19e7505ac6e1",
    "url": "/img/my-readings.80eadca6.svg"
  },
  {
    "revision": "bc7283a7ce58936bce83e3ead2e8d855",
    "url": "/img/my-tickets.bc7283a7.svg"
  },
  {
    "revision": "79cd3737aee46a4c5759cbf18b0b57e3",
    "url": "/img/next-normal.79cd3737.svg"
  },
  {
    "revision": "7b6c34f2e7d45581efa4b65fd94ab8ec",
    "url": "/img/openeye.png"
  },
  {
    "revision": "52d308be8a8907e20e0550a63e9f79f2",
    "url": "/img/profileImg@2x.52d308be.png"
  },
  {
    "revision": "52d308be8a8907e20e0550a63e9f79f2",
    "url": "/img/profileImg@2x.png"
  },
  {
    "revision": "dd542e80b0b7b30543f9208b4b99708a",
    "url": "/img/ribbon.dd542e80.png"
  },
  {
    "revision": "dd542e80b0b7b30543f9208b4b99708a",
    "url": "/img/ribbon.png"
  },
  {
    "revision": "307845e192f78fde5ff8ae37323f624a",
    "url": "/img/scanner.307845e1.svg"
  },
  {
    "revision": "0ebcf7aa1fdbc086339f13a236c17ebd",
    "url": "/img/setting.0ebcf7aa.svg"
  },
  {
    "revision": "0fac4c0764d775d45756fdcb129d3db1",
    "url": "/img/subs-level-diamond.0fac4c07.svg"
  },
  {
    "revision": "dca6a8d0904d0d2eaaf6897c9e582953",
    "url": "/img/subs-level-gold.dca6a8d0.svg"
  },
  {
    "revision": "19cc25ddf7886829975b8ae871334c2f",
    "url": "/img/subs-level-silver.19cc25dd.svg"
  },
  {
    "revision": "f4549ab5142e42c22dca2c379a224111",
    "url": "/img/toRight@2x.png"
  },
  {
    "revision": "4a00ce28dc57fd3c9220ca3c1d20f338",
    "url": "/img/userDefault01@2x.4a00ce28.png"
  },
  {
    "revision": "4a00ce28dc57fd3c9220ca3c1d20f338",
    "url": "/img/userDefault01@2x.png"
  },
  {
    "revision": "2bb7ebc86fbfed61053404bda581ac43",
    "url": "/img/win@2x.2bb7ebc8.png"
  },
  {
    "revision": "2bb7ebc86fbfed61053404bda581ac43",
    "url": "/img/win@2x.png"
  },
  {
    "revision": "9a92a825c61772bb807f956eeb0180f6",
    "url": "/index.html"
  },
  {
    "revision": "2b356a45a6241e168e2b",
    "url": "/js/app.444a960a.js"
  },
  {
    "revision": "8c72acacd3bb8784796b",
    "url": "/js/chunk-059a9036.2e8ffd69.js"
  },
  {
    "revision": "28a559b7ae9470575f9c",
    "url": "/js/chunk-086d6913.4fd5b100.js"
  },
  {
    "revision": "3308354fd5d93e00ca1d",
    "url": "/js/chunk-0aeba7b0.df941dfd.js"
  },
  {
    "revision": "108eb9e2cfeb3013283a",
    "url": "/js/chunk-11a15cea.477d7d7d.js"
  },
  {
    "revision": "423ebe41401c94e368ec",
    "url": "/js/chunk-11c051be.ce0ab7d2.js"
  },
  {
    "revision": "fbb03148db2fe6aed7bb",
    "url": "/js/chunk-12bb8356.80938a02.js"
  },
  {
    "revision": "b10ce2faf9c5d388d007",
    "url": "/js/chunk-1732b481.d4442dea.js"
  },
  {
    "revision": "828927a93b1aad05a4db",
    "url": "/js/chunk-1b058946.051e97ca.js"
  },
  {
    "revision": "ec1f83ac3a3d7d1aa4f9",
    "url": "/js/chunk-1d9633de.503967a3.js"
  },
  {
    "revision": "c83be8297eae3499cfd2",
    "url": "/js/chunk-1e240052.47d1051d.js"
  },
  {
    "revision": "89a64ee81a3529676036",
    "url": "/js/chunk-22c2b826.2a93d867.js"
  },
  {
    "revision": "2bc8f484a6e16167fcd6",
    "url": "/js/chunk-26c4349a.b875dfb5.js"
  },
  {
    "revision": "df4bf0fac4100f805477",
    "url": "/js/chunk-2d0aade4.e7b74e73.js"
  },
  {
    "revision": "9a12c2dc5c0d72669623",
    "url": "/js/chunk-2d0af103.2be80ab7.js"
  },
  {
    "revision": "c7c8af056df18f540d17",
    "url": "/js/chunk-2d0b2ef9.5517f8c4.js"
  },
  {
    "revision": "594b3ceac0f579b7bc0b",
    "url": "/js/chunk-2d0b6c7f.6d08a665.js"
  },
  {
    "revision": "27a1970558c39cedb3c4",
    "url": "/js/chunk-2d0c87c6.0c53a18a.js"
  },
  {
    "revision": "dcb77017dac1b6616071",
    "url": "/js/chunk-2d0cb6c1.f1eac4bf.js"
  },
  {
    "revision": "b8111e6458a69afec359",
    "url": "/js/chunk-2d0ddfea.41660480.js"
  },
  {
    "revision": "8772fea43708cb3a163d",
    "url": "/js/chunk-2d225b8a.63f1adbb.js"
  },
  {
    "revision": "5b1a1a8026eb49b4c64a",
    "url": "/js/chunk-2d226756.78447a1e.js"
  },
  {
    "revision": "86e500ca56772bf8e529",
    "url": "/js/chunk-2d22dd78.7531373f.js"
  },
  {
    "revision": "18f7a6acde757e8baf69",
    "url": "/js/chunk-33f72688.226d2d09.js"
  },
  {
    "revision": "16a878f0c399dd17c89a",
    "url": "/js/chunk-369627a0.a83aa1c3.js"
  },
  {
    "revision": "5cbdc5f1e7d57e5fe73c",
    "url": "/js/chunk-3bc44cd0.55e76911.js"
  },
  {
    "revision": "2d080e7c2f17c6d45569",
    "url": "/js/chunk-400508db.f351b6a9.js"
  },
  {
    "revision": "cae63de5f6a88490cea8",
    "url": "/js/chunk-4315725a.2ca4568d.js"
  },
  {
    "revision": "27df45f107dc531c0a01",
    "url": "/js/chunk-45dde748.37a3c6a5.js"
  },
  {
    "revision": "e917ed5f07e61ffbb3b0",
    "url": "/js/chunk-49723b1f.42ce433c.js"
  },
  {
    "revision": "47099a9b25841cabe89a",
    "url": "/js/chunk-4a452910.100dfa91.js"
  },
  {
    "revision": "99c3b1622624c3522c61",
    "url": "/js/chunk-5392d39b.42344841.js"
  },
  {
    "revision": "b79c0799313cb77ea2c6",
    "url": "/js/chunk-54fb6ee4.4ed478d0.js"
  },
  {
    "revision": "3477fa9c81dc1577c24e",
    "url": "/js/chunk-55972381.80fb4aa5.js"
  },
  {
    "revision": "27047c8aa79a6945dd7f",
    "url": "/js/chunk-5c2afa9e.b67d515e.js"
  },
  {
    "revision": "2f12a8dfcaf1850acc35",
    "url": "/js/chunk-5e61636b.c1d0f7fa.js"
  },
  {
    "revision": "69b972d13885f7e2b430",
    "url": "/js/chunk-5ef89607.7816fee5.js"
  },
  {
    "revision": "ce83392c49021bf88c5c",
    "url": "/js/chunk-6927cf5a.c8d34717.js"
  },
  {
    "revision": "ae6282075351ccfe99a4",
    "url": "/js/chunk-6b4ad46e.ee255df0.js"
  },
  {
    "revision": "6692714f1f4b69f0eb9c",
    "url": "/js/chunk-6c45f638.382bd908.js"
  },
  {
    "revision": "6f164c5fe3cdc1c55ae9",
    "url": "/js/chunk-6cb91a4c.d30f9d91.js"
  },
  {
    "revision": "168085680068c9e43e81",
    "url": "/js/chunk-6f25d778.2340ad16.js"
  },
  {
    "revision": "43bf560161ca65857531",
    "url": "/js/chunk-6fe5a6da.1849156e.js"
  },
  {
    "revision": "5ee98f5bc8ca2fa579d6",
    "url": "/js/chunk-7375a8a3.0cf15171.js"
  },
  {
    "revision": "227c28cfec9478a142f5",
    "url": "/js/chunk-758b05b8.00917080.js"
  },
  {
    "revision": "f5262b2296c4d9fca175",
    "url": "/js/chunk-77bd8f78.27b4bd3c.js"
  },
  {
    "revision": "a6a41375c34e6a7503cc",
    "url": "/js/chunk-7aa3d659.ac456dd0.js"
  },
  {
    "revision": "6bac4cadb74e5086211a",
    "url": "/js/chunk-7c46f24c.0d7c8844.js"
  },
  {
    "revision": "342e1a62107289937911",
    "url": "/js/chunk-7e278922.e9b040c0.js"
  },
  {
    "revision": "d5ec8ae0bd236354957f",
    "url": "/js/chunk-82cceff6.24e40951.js"
  },
  {
    "revision": "ff12b45acc4226e2b43b",
    "url": "/js/chunk-83853f8a.a17ab744.js"
  },
  {
    "revision": "4f54dfd7c29e96ba3f9f",
    "url": "/js/chunk-8f074734.68a04f4b.js"
  },
  {
    "revision": "d36d38a3a4a7b12a8b2e",
    "url": "/js/chunk-bf9ad81e.b3849960.js"
  },
  {
    "revision": "9f89c08f971906355408",
    "url": "/js/chunk-e3a85116.890095fe.js"
  },
  {
    "revision": "1fb07d6eff61f9f56412",
    "url": "/js/chunk-e8e36cc0.7db54fc5.js"
  },
  {
    "revision": "1cc763d8170d60521f83",
    "url": "/js/chunk-fae3c8be.a3d5d6d0.js"
  },
  {
    "revision": "77e92951086cc374cb0e",
    "url": "/js/chunk-vendors.e856e60c.js"
  },
  {
    "revision": "909e2a7e526f61ed56e7482abf43476c",
    "url": "/manifest.json"
  },
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/robots.txt"
  }
]);