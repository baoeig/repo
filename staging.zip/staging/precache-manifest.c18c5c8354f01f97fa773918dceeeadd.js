self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "d6b4509bc3a0633dd02d",
    "url": "/css/app.32114fed.css"
  },
  {
    "revision": "827635b2ec2630dd4b05",
    "url": "/css/chunk-5323824a.1642bd13.css"
  },
  {
    "revision": "ae0f4359bd90823389d6e57b303b3174",
    "url": "/img/apple-brands.ae0f4359.svg"
  },
  {
    "revision": "e7c5d21fc53c863a5dae21a321f29562",
    "url": "/img/b_coin_popup.e7c5d21f.svg"
  },
  {
    "revision": "afe501ca799f64d9210db1e48349550d",
    "url": "/img/backBlack.afe501ca.svg"
  },
  {
    "revision": "395b4a31d45247751d58d8593e9f9d98",
    "url": "/img/backWhite.395b4a31.svg"
  },
  {
    "revision": "b9607337623c11bd92fdc2fc9ee80917",
    "url": "/img/bw-icon.b9607337.svg"
  },
  {
    "revision": "42f76ddf21319a931ce3b2c5287cd40a",
    "url": "/img/checkmark-black.42f76ddf.svg"
  },
  {
    "revision": "86c654f077f98b9543b78954452b9412",
    "url": "/img/clock.86c654f0.svg"
  },
  {
    "revision": "5513e2047dda3bd98e6b51a0524b3e2a",
    "url": "/img/close.5513e204.svg"
  },
  {
    "revision": "9357555aaaa42abd7cece04fa01281d5",
    "url": "/img/exchange-center-banner.9357555a.png"
  },
  {
    "revision": "ef3e3e7b86f8a7cc0870b3b7d88b9da1",
    "url": "/img/exchange-center.ef3e3e7b.svg"
  },
  {
    "revision": "5d24a4334a694c87f304e6407115664b",
    "url": "/img/facebook-brands-white.5d24a433.svg"
  },
  {
    "revision": "11834243862205db2d7c0cda6e98fa9f",
    "url": "/img/facebook-brands.11834243.svg"
  },
  {
    "revision": "69186010ebf326b8813eb3e928c20981",
    "url": "/img/faq.69186010.svg"
  },
  {
    "revision": "734f8fa8be51cc15988dd3031e4fdd27",
    "url": "/img/google-brands.734f8fa8.svg"
  },
  {
    "revision": "cba982650baccc75c3809f512fd0e001",
    "url": "/img/hint.cba98265.svg"
  },
  {
    "revision": "b5aa263343ddbdb4672198a397af131d",
    "url": "/img/how-to-earn-points.b5aa2633.svg"
  },
  {
    "revision": "d35eefbf15b5bf40113f199a19640b63",
    "url": "/img/icRegularSubscribe.d35eefbf.png"
  },
  {
    "revision": "a1c8fbb33d2188d818772b8272c37506",
    "url": "/img/icicon2@2x.a1c8fbb3.png"
  },
  {
    "revision": "55fcd06797e02335c2eb571b87537827",
    "url": "/img/iconPerson@2x.55fcd067.png"
  },
  {
    "revision": "6d9ac81d78e56d1d2ba1e49a1276d87e",
    "url": "/img/info-dark.6d9ac81d.svg"
  },
  {
    "revision": "a6052ee59ded8389d776469dea2fdf51",
    "url": "/img/line-brands-white.a6052ee5.svg"
  },
  {
    "revision": "eda77f2accfaf3885d7ab3a9d6fa8b07",
    "url": "/img/line-brands.eda77f2a.svg"
  },
  {
    "revision": "3cc18edc5611a8ff8d5ff7c288188ac6",
    "url": "/img/my-points.3cc18edc.svg"
  },
  {
    "revision": "80eadca6026238350d0e19e7505ac6e1",
    "url": "/img/my-readings.80eadca6.svg"
  },
  {
    "revision": "bc7283a7ce58936bce83e3ead2e8d855",
    "url": "/img/my-tickets.bc7283a7.svg"
  },
  {
    "revision": "79cd3737aee46a4c5759cbf18b0b57e3",
    "url": "/img/next-normal.79cd3737.svg"
  },
  {
    "revision": "52d308be8a8907e20e0550a63e9f79f2",
    "url": "/img/profileImg@2x.52d308be.png"
  },
  {
    "revision": "dd542e80b0b7b30543f9208b4b99708a",
    "url": "/img/ribbon.dd542e80.png"
  },
  {
    "revision": "307845e192f78fde5ff8ae37323f624a",
    "url": "/img/scanner.307845e1.svg"
  },
  {
    "revision": "0ebcf7aa1fdbc086339f13a236c17ebd",
    "url": "/img/setting.0ebcf7aa.svg"
  },
  {
    "revision": "0fac4c0764d775d45756fdcb129d3db1",
    "url": "/img/subs-level-diamond.0fac4c07.svg"
  },
  {
    "revision": "dca6a8d0904d0d2eaaf6897c9e582953",
    "url": "/img/subs-level-gold.dca6a8d0.svg"
  },
  {
    "revision": "19cc25ddf7886829975b8ae871334c2f",
    "url": "/img/subs-level-silver.19cc25dd.svg"
  },
  {
    "revision": "4a00ce28dc57fd3c9220ca3c1d20f338",
    "url": "/img/userDefault01@2x.4a00ce28.png"
  },
  {
    "revision": "2bb7ebc86fbfed61053404bda581ac43",
    "url": "/img/win@2x.2bb7ebc8.png"
  },
  {
    "revision": "d69ac5b8e7f938bebda9d58a7bfd5491",
    "url": "/index.html"
  },
  {
    "revision": "d6b4509bc3a0633dd02d",
    "url": "/js/app-legacy.a45eb370.js"
  },
  {
    "revision": "5d978b1646489dfbb481",
    "url": "/js/chunk-0208b3a4-legacy.d3d1ac78.js"
  },
  {
    "revision": "c3b6db1bda8473bcbd23",
    "url": "/js/chunk-059a9036-legacy.2d480f53.js"
  },
  {
    "revision": "4664cec20ff5f2f96d4e",
    "url": "/js/chunk-086d6913-legacy.a51389c4.js"
  },
  {
    "revision": "e95a5333f5aa938ea0f1",
    "url": "/js/chunk-12bb8356-legacy.b32facbc.js"
  },
  {
    "revision": "351a7cdcd5cbe5f4dbc0",
    "url": "/js/chunk-1b058946-legacy.edca50d7.js"
  },
  {
    "revision": "88fcbc850da010b23822",
    "url": "/js/chunk-1d9633de-legacy.592733f0.js"
  },
  {
    "revision": "6b1ef38b03948b19ea6e",
    "url": "/js/chunk-1e240052-legacy.e9aec609.js"
  },
  {
    "revision": "9a0af42b7a720ed7238d",
    "url": "/js/chunk-1f809738-legacy.2e144682.js"
  },
  {
    "revision": "45443c6b4e7143340ec0",
    "url": "/js/chunk-26c4349a-legacy.40faf19f.js"
  },
  {
    "revision": "eab5eb6b453b56043f78",
    "url": "/js/chunk-29f65847-legacy.418b7d9c.js"
  },
  {
    "revision": "405261ecb2a30d656df7",
    "url": "/js/chunk-2c93cf18-legacy.e4c8e866.js"
  },
  {
    "revision": "f8a870515427ddce9c8a",
    "url": "/js/chunk-2ce8e65c-legacy.8b82df10.js"
  },
  {
    "revision": "7dd0d325ca9b2ce001b2",
    "url": "/js/chunk-2d0aad78-legacy.e41cbe62.js"
  },
  {
    "revision": "11d2ae684a902a8000f4",
    "url": "/js/chunk-2d0aade4-legacy.02ba0d02.js"
  },
  {
    "revision": "5ffa262afdefe036a246",
    "url": "/js/chunk-2d0b6c7f-legacy.45beb845.js"
  },
  {
    "revision": "43005be2da8a218dc339",
    "url": "/js/chunk-2d0cb6c1-legacy.29cad7e0.js"
  },
  {
    "revision": "1a484fa5dc68ed752fe1",
    "url": "/js/chunk-2d0ddfea-legacy.ac8e2670.js"
  },
  {
    "revision": "c3e50af7573b4aebcb89",
    "url": "/js/chunk-2d209000-legacy.3c4ca21a.js"
  },
  {
    "revision": "f71ed025c4d4450b483d",
    "url": "/js/chunk-2d225b8a-legacy.fe009bac.js"
  },
  {
    "revision": "e32e8595b4383804e584",
    "url": "/js/chunk-2d226756-legacy.fb7e7a24.js"
  },
  {
    "revision": "86e500ca56772bf8e529",
    "url": "/js/chunk-2d22dd78-legacy.7531373f.js"
  },
  {
    "revision": "ceaedf236d6bed108af7",
    "url": "/js/chunk-2d2306b6-legacy.61ed11af.js"
  },
  {
    "revision": "36258c0a3d1d656cd728",
    "url": "/js/chunk-2d5fc520-legacy.a479aa5f.js"
  },
  {
    "revision": "2036d8357d66cfe2241e",
    "url": "/js/chunk-2dd73100-legacy.942f4404.js"
  },
  {
    "revision": "8978d884b38efa7bbb94",
    "url": "/js/chunk-377bdb6d-legacy.5cf8598b.js"
  },
  {
    "revision": "1d88940c704e5d74b032",
    "url": "/js/chunk-4315725a-legacy.96242e52.js"
  },
  {
    "revision": "f9f393d74d30fe5a3926",
    "url": "/js/chunk-43acae62-legacy.fcd4132f.js"
  },
  {
    "revision": "a5bbba1e47aec28a00c7",
    "url": "/js/chunk-4a452910-legacy.e4441816.js"
  },
  {
    "revision": "03f51b78b330a1866a01",
    "url": "/js/chunk-4ea94b62-legacy.bc85bbf4.js"
  },
  {
    "revision": "827635b2ec2630dd4b05",
    "url": "/js/chunk-5323824a-legacy.0e9b38c9.js"
  },
  {
    "revision": "749db9314ad4d38be3e7",
    "url": "/js/chunk-5392d39b-legacy.4071c453.js"
  },
  {
    "revision": "3477fa9c81dc1577c24e",
    "url": "/js/chunk-55972381-legacy.80fb4aa5.js"
  },
  {
    "revision": "1a0157b0a28f8dff730d",
    "url": "/js/chunk-5a6ae50b-legacy.f6474c0f.js"
  },
  {
    "revision": "c4460f111a72c9b0b056",
    "url": "/js/chunk-5b6b9807-legacy.7c43cb16.js"
  },
  {
    "revision": "0ad9c96e459c3fa9da25",
    "url": "/js/chunk-5e26e73a-legacy.497fdfe3.js"
  },
  {
    "revision": "f20967ea612e56147123",
    "url": "/js/chunk-5f12a583-legacy.141b98f3.js"
  },
  {
    "revision": "16855f9dc8aaaba9b5f4",
    "url": "/js/chunk-64640ff5-legacy.ab48f53d.js"
  },
  {
    "revision": "a37d01c9059122ff410d",
    "url": "/js/chunk-6c45f638-legacy.2527838f.js"
  },
  {
    "revision": "e1d9625b58db7db47d06",
    "url": "/js/chunk-715bc2cd-legacy.e8035398.js"
  },
  {
    "revision": "bfb29f1f9f9830988af4",
    "url": "/js/chunk-74c2b674-legacy.3c2a0bc4.js"
  },
  {
    "revision": "1e7a1e7dcc11a3c032a1",
    "url": "/js/chunk-74eedba2-legacy.ba2197ba.js"
  },
  {
    "revision": "2bdf1d14e7e83c917ded",
    "url": "/js/chunk-7f87e7c4-legacy.4648fb46.js"
  },
  {
    "revision": "377773a1f26c7d06f9f4",
    "url": "/js/chunk-7fc52cfe-legacy.bb9e912a.js"
  },
  {
    "revision": "dac121df885916e5f1d3",
    "url": "/js/chunk-82cceff6-legacy.39a3395b.js"
  },
  {
    "revision": "cd397b10c990c26f38f6",
    "url": "/js/chunk-84f4fe10-legacy.5be19719.js"
  },
  {
    "revision": "a16dfd6c22a67baf4b10",
    "url": "/js/chunk-896f9ea2-legacy.6bebe1e5.js"
  },
  {
    "revision": "3add7f6c7732ce1b0c63",
    "url": "/js/chunk-8dcbb1a2-legacy.254a2d2a.js"
  },
  {
    "revision": "ba2d539083f1a2b81ec0",
    "url": "/js/chunk-931553f8-legacy.638778f6.js"
  },
  {
    "revision": "a1d78fff413d1ef06d8e",
    "url": "/js/chunk-a28b49c8-legacy.ce48e433.js"
  },
  {
    "revision": "69af8e2c0e5a53eb83f9",
    "url": "/js/chunk-ac6e5c36-legacy.5ca5ea11.js"
  },
  {
    "revision": "bbe1dbbb1bf98a667054",
    "url": "/js/chunk-c26da092-legacy.9af5e887.js"
  },
  {
    "revision": "28fb65cd2f917f65875c",
    "url": "/js/chunk-cee44ad6-legacy.6fd8c27a.js"
  },
  {
    "revision": "d66d8f3d633932492659",
    "url": "/js/chunk-cf9c86c4-legacy.ab0a2bbd.js"
  },
  {
    "revision": "ff30490f2f797497d597",
    "url": "/js/chunk-d36e633a-legacy.3334c15f.js"
  },
  {
    "revision": "28677a2b5bbcff7d2b62",
    "url": "/js/chunk-d432e212-legacy.c98fa069.js"
  },
  {
    "revision": "84380460c53fcd9a424a",
    "url": "/js/chunk-e488c866-legacy.20aa0720.js"
  },
  {
    "revision": "44a886050393ee0589c3",
    "url": "/js/chunk-vendors-legacy.55603aed.js"
  },
  {
    "revision": "909e2a7e526f61ed56e7482abf43476c",
    "url": "/manifest.json"
  }
]);